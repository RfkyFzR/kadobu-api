const FRONT_END_URL = process.env.FRONT_END_URL;

module.exports = { FRONT_END_URL };
